#include <fstream>  // Para ofstream
#include <iostream> // Para cout
#include <vector>
using namespace std;

string introduce_nombre_fichero();
int menu();
void introduce_nota(const string& nombre_fichero);
void lee_notas(const string& nombre_fichero, vector<string>& dnis,vector<double>& notas);
void listado(const vector<string>& dnis,const vector<double>& notas,
             size_t indice_minima, size_t indice_maxima, double media);
void calcula_estadisticas(const string& nombre_fichero);

int main()
{
  string nombre_fichero = introduce_nombre_fichero();
  while (int opcion = menu())
    if (opcion == 1)
      introduce_nota(nombre_fichero);
    else
      calcula_estadisticas(nombre_fichero);
}

string introduce_nombre_fichero()
{
    cout << "Nombre con extension del fichero de notas: ";
    string nombre_fichero;
    cin >> nombre_fichero;
    return nombre_fichero;
}

int menu()
{
  int opcion;
  do
  {
    cout << "Pulse 0 para salir del programa\n"
         << "Pulse 1 para introducir nota\n"
         << "Pulse 2 para listado y estadisticas\n";
    cin >> opcion;
  }
  while (opcion < 0 || opcion > 2);
  return opcion;
}

void introduce_nota(const string& nombre_fichero)
{
  cout << "Nombre y Apellido del Alumno(Nombre.Apellido): ";
  string dni;
  cin >> dni;
  
  double nota;
  do
  {
    cout << "Nota: ";
    cin >> nota;
    if (nota < 0 || nota > 7)
      cout << "\n\nERROR: La nota no es válida.\n\n";
  }while (nota < 0 || nota > 7);
  
  ofstream fichero(nombre_fichero, ios::app);
  if (!fichero)
  {
    cout << "Error, "<< nombre_fichero
         << " no pudo abrirse para escritura.\n";
    exit(EXIT_FAILURE);
  }
  fichero << dni << " " << nota << endl;
}

void lee_notas(const string& nombre_fichero,
               vector<string>& dnis, vector<double>& notas)
{
  ifstream fichero(nombre_fichero);
  if (!fichero)
  {
    cout << "Error, "<< nombre_fichero
         << " no pudo abrirse para lectura.\n";
    exit(EXIT_FAILURE);
  }

  string dni;
  while (fichero >> dni)
  {
    dnis.push_back(dni);
    double nota;
    fichero >> nota;
    notas.push_back(nota);
  }
}

void listado(const vector<string>& dnis,const vector<double>& notas,
             size_t indice_minima, size_t indice_maxima, double media)
{
  cout << "******************************************\n";
  for (size_t i = 0; i < dnis.size(); ++i)
    cout << dnis[i] << " " << notas[i] << endl;
  cout << "******************************************\n";
  cout << "Nota minima: " << dnis[indice_minima]
       << " con nota " << notas[indice_minima] << endl;
  cout << "Nota maxima: " << dnis[indice_maxima]
       << " con nota " << notas[indice_maxima] << endl;
  cout << "Nota media: " << media << endl;
  cout<<"******************************************\n";
}

void calcula_estadisticas(const string& nombre_fichero)
{
  vector<string> dnis;
  vector<double> notas;
  lee_notas(nombre_fichero, dnis, notas);

  if (dnis.empty())
  {
    cout << "\n\nEl fichero esta vacío.\n\n";
    return;
  }
    
  size_t indice_minima = 0, indice_maxima = 0;
  double nota_minima = notas[0];
  double nota_maxima = notas[0];
  double media = 0.;
    
  for (size_t i = 0; i < dnis.size(); ++i)
  {
    if (notas[i] < nota_minima)
    {
      nota_minima = notas[i];
      indice_minima = i;
    }
    else if (notas[i] > nota_maxima)
    {
      nota_maxima = notas[i];
      indice_maxima = i;
    }
    media += notas[i];
  }
  media /= dnis.size();

  listado(dnis, notas, indice_minima, indice_maxima, media);
}