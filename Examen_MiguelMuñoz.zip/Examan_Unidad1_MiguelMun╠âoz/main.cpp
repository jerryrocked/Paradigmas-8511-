#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

class Persona {
public:
  struct {
    string nom;
    int edad;
    int i, j, clientes, rango, lon, valor, nin = 0, jov = 0, ad = 0;
    string linea;
  } reg;
  Persona(){};
  ~Persona(){};
  int datos();
  void rango_edad(int edad);
  void boleta();
  void registro();
  int leerlinea(string linea);
  int leerregistro();
  void cantidades();
  void ingresos();
  void porcentaje();
};

int Persona::datos() {
  cout << "Ingrese" << endl;
  cout << "-------------------" << endl;
  cout << "Nombre: ";
  getline(cin, reg.nom);
  cout << "Edad: ";
  cin >> reg.edad;
  cout << "-------------------" << endl;
  return reg.edad;
};

void Persona::rango_edad(int edad) {
  if (5 <= edad and edad <= 12) {
    //reg.rango = 1;
    reg.nin = reg.nin + 1;
    reg.valor = 4000;
  }
  if (13 <= edad and edad <= 25) {
    //reg.rango = 2;
    reg.jov = reg.jov + 1;
    reg.valor = 6000;
  }
  if (25 < edad and edad < 99) {
    //reg.rango = 3;
    reg.ad = reg.ad + 1;
    reg.valor = 6000;
  }
};

void Persona::registro() {
  string filename("clientes.txt");
  ofstream file;
  file.open(filename, ios_base::app);
  file << reg.nom << " " << reg.edad << endl;
}

int Persona::leerlinea(string linea) {
  int lon = 0, i, j = 0, edad;
  string ed;
  char l, b;
  lon = reg.linea.length();
  if (lon != 0) {
    for (i = 0; i < lon; i++) {
      l = reg.linea[i];
      b = ' ';
      if (l != b) {
        if (j == 1)
          ed = ed + reg.linea[i];
      } else {
        j++;
      }
    }
    stringstream ss;
    ss << ed;
    ss >> edad;
    rango_edad(edad);
  }
  return edad;
};

int Persona::leerregistro() {
  int c = 0;
  ifstream file("clientes.txt");
  while (!file.eof()) {
    getline(file, reg.linea);
    c++;
    reg.lon = reg.linea.length();
    leerlinea(reg.linea);
  }
  return c;
};

void Persona::boleta() {
  reg.clientes = (leerregistro() - 1);
  cout << endl;
  cout << "Boleta" << endl;
  cout << "-------------" << endl;
  cout << "Nombre: " << reg.nom << endl;
  cout << "Edad: " << reg.edad << endl;
  cout << "-------------" << endl;
  cout << "Precio: $" << reg.valor << endl;
};

void Persona::cantidades() {
  int total;
  total = reg.nin + reg.jov + reg.ad;
  cout << endl;
  cout << "Clientes" << endl;
  cout << "-------------" << endl;
  cout << "Niños: " << reg.nin << endl;
  cout << "Jovenes: " << reg.jov << endl;
  cout << "Adultos: " << reg.ad << endl;
  cout << "-------------" << endl;
  cout << "Total: " << total << endl;
};

void Persona::ingresos() {
  int i_n, i_j, i_a, total;
  i_n = reg.nin * 4000;
  i_j = reg.jov * 6000;
  i_a = reg.ad * 6000;
  total = i_n + i_j + i_a;
  cout << endl;
  cout << "Ingresos" << endl;
  cout << "---------------" << endl;
  cout << "Niños: $" << i_n << endl;
  cout << "Jovenes: $" << i_j << endl;
  cout << "Adultos: $" << i_a << endl;
  cout << "---------------" << endl;
  cout << "Total: $" << total << endl;
};

void Persona::porcentaje() {
  float po_n, po_j, po_a;
  po_n = (reg.nin * 100) / reg.clientes;
  po_j = (reg.jov * 100) / reg.clientes;
  po_a = (reg.ad * 100) / reg.clientes;
  cout << endl;
  cout << "Porcentajes" << endl;
  cout << "-------------" << endl;
  cout << "Niños: " << po_n << "%" << endl;
  cout << "Jovenes: " << po_j << "%" << endl;
  cout << "Adultos: " << po_a << "%" << endl;
  cout << "-------------" << endl;
};

int main() {
  Persona p;
  cout << "-------------------" << endl;
  cout << "Cine XYZ estrena:" << endl;
  cout << "*'TOP GUN: Maverick'*" << endl;
  cout << "-------------------" << endl;
  cout << endl;
  p.datos();
  p.registro();
  p.boleta();
  p.cantidades();
  p.ingresos();
  p.porcentaje();
  return 0;
};