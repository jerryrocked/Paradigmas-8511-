inicio:-falla(Caracteristica),
    write('Su automovil no enciende debido a: '),
    write(Caracteristica),nl.
	%undo.
falla(alternador):-alternador, !.
falla(motor_de_arranque):-motor_de_arranque, !.
falla(interruptor_de_encendido):-interruptor_de_encendido, !.
falla(bujias):-bujias, !.
falla(tapa_de_distribuidor):-tapa_de_distribuidor, !.
falla(correa_de_distribuición):-correa_de_distribuición, !.
falla(bloqueo_de_la_dirección):-bloqueo_de_la_dirección, !.
falla(gasolina):-gasolina, !.
falla(desconocida).

alternador:-
	verifica(alternador_defectuoso).
motor_de_arranque:-   
    verifica(error_motor_de_arranque).
interruptor_de_encendido:-
    verifica(interruptor_de_encendido_defectuoso).
bujias:-
    verifica(error_bujías).
tapa_de_distribuidor:-
    verifica(tapa_de_distribuidor_rota).
correa_de_distribuición:-
    verifica(correa_de_distribuición_en_mal_estado).
bloqueo_de_la_dirección:-
    verifica(bloqueo_de_la_dirección_atascado).
gasolina:-
    verifica(falta_de_gasolina).


respuesta(Pregunta):-
    write('Su automovil tiene '),
    write(Pregunta),write('? '),
    read(Respuesta),nl,
    ((Respuesta == si ; Respuesta == s) ->  
    	assert(si(Pregunta));
    	assert(no(Pregunta)),fail).

:- dynamic si/1,no/1.
verifica(S) :- (si(S) ->  true;
               (no(S) ->  fail;
               respuesta(S))).

undo :- retract(si(_)),fail.
undo :- retract(no(_)),fail.
undo. 