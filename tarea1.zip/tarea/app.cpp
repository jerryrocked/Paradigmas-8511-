#include <stdlib.h>
#include <iostream>
#include <fstream>
#include "Alumno.cpp"

#define ALUM_NUM 7
using namespace std;

int main() {
    //Variables lectura archivo
    string archivo1 = "archivo1.txt";
    ifstream archivo(archivo1.c_str());
    string linea;
    
    //Los alumnos
    Alumno alumnos[ALUM_NUM];

    //Variables lógicas del programa
    int res,lon,i,indice_alumno = 0;
    char l;

    while (getline(archivo,linea)) { //Recorrer c/fila del archivo
        int j = 0; //j corresponde a separar las "pegas"
        lon = linea.length(); //Largo de la fila
        
        //Variable temporales para guardar la data.
        string nomb, n1, n2, n3, n4; 
        float N1, N2, N3, N4;

        for (i=0;i<lon;i++){ //Recorrer c/caracter de fila
            l = linea[i]; //Obtener el caracter
            //Obtener los diferentes valores de cada fila y guardar en variables.
            if(l != ' '){ //Si el caracter es vacío, significa cambio de variable
                //Concatenar a la variable correspondiente
                if (j == 0)
                    nomb = nomb + linea[i];
                if (j == 1)
                    n1 = n1 + linea[i];
                if (j == 2)
                    n2 = n2 + linea[i];
                if (j == 3)
                    n3 = n3 + linea[i];
                if (j == 4)
                    n4 = n4 + linea[i];
            }else j++; //Cambiar de "pega"
        }

        //stoi --> convierte de str a int y casteamos para transormat dicho proceso a float "real"
        N1 = (float)stoi(n1);
        N2 = (float)stoi(n2);
        N3 = (float)stoi(n3);
        N4 = (float)stoi(n4);

        //Insetar las variables obtenidas en los atributos de el objeto alumno en la posición indice_alumno
        alumnos[indice_alumno++].setAttributes(nomb, N1, N2, N3, N4);
        //Ya que indice_alumno++ --> que luego de la línea 55 termina se le suma 1 a indice_alumno
    }

    for(int k=0;k<ALUM_NUM;k++){ //Recorrer los alumnos
        cout << endl << "Alumno  " << k << endl; //Decir que alumno voy a imprimir
        alumnos[k].imprimeme(); //Imprimo al alumno
    }

    return 0; //End :D
}