%Entradas
entrada(paella).
entrada(gaspacho).
entrada(pasta).

%Carnes
carne(bisteck).
carne(pollo).
carne(cerdo).

%Pescados
pescado(trucha).
pescado(bacalao).

%Postres
postre(flan).
postre(naranja).
postre(nueces).
postre(manzana).
postre(tres_leches).

%Precios
precios(paella,20).
precios(gaspacho,15).
precios(pasta,30).
precios(bisteck,50).
precios(pollo,28).
precios(cerdo,40).
precios(trucha,16).
precios(bacalo,30).
precios(flan,3).
precios(naranja,1).
precios(nueces,2).
precios(manzana,1).
precios(tres_leches,4).

%Platos Principales
plato_principal(Plato):-
    carne(Plato).
plato_principal(Plato):-
    pescado(Plato).

%Menu
menu(Entrada,Plato_Principal,Postre):-
    pedido(Entrada,Plato_Principal,Postre),
    precio_total(Entrada,Plato_Principal,Postre,Precio),
	write('El precio_total es de: '),
	write(Precio).

%Comidas
pedido(Entrada,Plato_Principal,Postre):-
    entrada(Entrada),
    plato_principal(Plato_Principal),
    postre(Postre).

%Precio Total
precio_total(Entrada,Plato_Principal,Postre,Precio):-
    precios(Entrada,X),
    precios(Plato_Principal,Y),
    precios(Postre,Z),
    sumar(X,Y,Z,Precio).

sumar(X,Y,Z,Res):-
    Res is X + Y + Z.
