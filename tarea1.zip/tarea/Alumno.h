#include <string>
#include <iostream>

class Alumno{
    private:
        std::string nombre;
        float n1, n2, n3, n4;
    public:
        void setAttributes(std::string nombre, float n1, float n2, float n3, float n4);
        void imprimeme();
};