inicio:-animal(Caracteristica),
    write('El animal es: '),
    write(Caracteristica),nl.
	%undo.
animal(tigre):-tigre, !.
animal(jaguar):-jaguar, !.
animal(jirafa):-jirafa, !.
animal(zebra):-zebra, !.
animal(elefante):-elefante, !.
animal(mono):-mono, !.
animal(desconocido).

tigre:-
    verifica(mamifero),
    verifica(carnivoro),
    verifica(color_amarillo),
    verifica(rayas_negras).
jaguar:-
    verifica(mamifero),
    verifica(carnivoro),
    verifica(color_amarillo),
    verifica(manchas_negras).
jirafa:-
    verifica(mamifero),
    verifica(herbivoro),
    verifica(color_amarillo),
    verifica(manchas_negras).
zebra:-
    verifica(mamifero),
    verifica(herbivoro),
    verifica(color_bn),
    verifica(rayas_negras).
elefante:-
    verifica(mamifero),
    verifica(herbivoro),
    verifica(color_gris),
    verifica(cuernos).
mono:-
    verifica(mamifero),
    verifica(omnivoro),
    verifica(color_negro).

respuesta(Pregunta):-
    write('El animal es '),
    write(Pregunta),write('? '),
    read(Respuesta),nl,
    ((Respuesta == si ; Respuesta == s) ->  
    	assert(si(Pregunta));
    	assert(no(Pregunta)),fail).

:- dynamic si/1,no/1.
verifica(S) :- (si(S) ->  true;
               (no(S) ->  fail;
               respuesta(S))).

undo :- retract(si(_)),fail.
undo :- retract(no(_)),fail.
undo.