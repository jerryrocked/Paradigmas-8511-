#include <iostream>
#include <string.h>
#include <fstream>
#include <cstdlib>
#include <iomanip>
using namespace std;
int main(){
    string archivo1="archivo1.txt";
    ifstream archivo(archivo1.c_str());
    string linea,nomb,n1,n2,n3,n4;
    float num1,num2,num3,num4;
    float lista[50];
    int res,lon,i,j=0;
    string arreglo[100];
    char b,l;

    while (getline(archivo,linea)) {
        cout<<linea<<endl;
        lon = linea.length();
        for (i=0;i<lon;i++){
            l=linea[i];
            b=' ';
            if (l!=b){
                if (j==0)
                    nomb=nomb+linea[i];
                if (j==1)
                    n1=n1+linea[i];
                if (j==2)
                    n2=n2+linea[i];
                if (j==3)
                    n3=n3+linea[i];
                if (j==4)
                    n4=n4+linea[i];    
            }
            else
                j++;
        }
        //cout<<nomb<<endl;
        //cout<<n1<<endl;
        //cout<<n2<<endl;
        //cout<<n3<<endl;
        //cout<<n4<<endl;
        num1 = stof(n1);
        num2 = stof(n2);
        num3 = stof(n3);
        num4 = stof(n4);
        lista[0] = num1;
        lista[1] = num2;
        lista[2] = num3;
        lista[3] = num4;
        cout<<fixed<<setprecision(1)<<lista[0]<<" "<<lista[1]<<" "<<lista[2]<<" "<<lista[3]<<endl;
        
        
        j=0;
        nomb=" ";
        n1=" ";
        n2=" ";
        n3=" ";
        n4=" ";
        }
  }