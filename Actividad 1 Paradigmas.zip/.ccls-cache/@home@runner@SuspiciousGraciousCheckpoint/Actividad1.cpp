#include <iostream>
using namespace std;
class Nodo
{
	public:
		string Nombre;
		Nodo * Siguiente;
};
int InsertarElemento(Nodo **Inicio, string dato)
{
	Nodo* nuevo_nodo = new Nodo();
	Nodo *ultimo = *Inicio;
	nuevo_nodo->Nombre = dato;
	nuevo_nodo->Siguiente = NULL;
		if (*Inicio == NULL)
	{
		*Inicio = nuevo_nodo;
		return 0;
	}
		while (ultimo->Siguiente != NULL)
	{
		ultimo = ultimo->Siguiente;
	}
		ultimo->Siguiente = nuevo_nodo;
		return 0;
	};	
void ListarElementos(Nodo *Inicio)
{
    
     Nodo *Recorrer = Inicio;
     
     cout<<"Elementos en la lista";
     
     
     while(Recorrer!=NULL)
     {
        cout<<Recorrer->Nombre<<endl;
        Recorrer=Recorrer->Siguiente;
     }
     
}
int BorrarElementoPrincipio(Nodo **Inicio)
{
	Nodo *Borrar=NULL;
    if ( *Inicio ==NULL) {
       cout<<"No hay elementos";
       return -1;
    } else {
      Borrar = *Inicio;
      *Inicio = (*Inicio)->Siguiente;
      delete (Borrar);
    }
    return 0;
}

int BorrarElementoMedio(Nodo **Inicio)
{ 
    Nodo *Recorrer=NULL;
    Nodo *Borrar=NULL;
    Nodo *Anterior=NULL;
    
    string NombreBuscar;
    int encontrado=0;
    
    cout<<"Nombre a eliminar: ";
    cin>>NombreBuscar;
   
    if (*Inicio==NULL) {
       cout<<"No hay elementos que borrar";
       return -1;
    } else {
        
        cout<<"Buscando... ",NombreBuscar;
        Recorrer = *Inicio;
        Anterior = *Inicio;
        while(Recorrer!=NULL && encontrado==0)
        {
            if(Recorrer->Nombre.compare(NombreBuscar)==0) {
                cout<<"Encontrado";
                encontrado=1;
                Borrar = Recorrer;
                if(Recorrer==*Inicio) {
                    *Inicio = Recorrer->Siguiente;
                } else {
                    Anterior->Siguiente = Borrar->Siguiente;
                }
                delete (Borrar);
            } else {
                
                Anterior = Recorrer;
                Recorrer=Recorrer->Siguiente;
            }
        }
        
    }
    return 0;
}
int BorrarElementoFinal(Nodo **Inicio)
{
    Nodo *Borrar=NULL;
    Nodo *Recorrer=NULL;
    Recorrer=*Inicio;
    if(Recorrer==NULL) {
     cout<<"No hay elementos";
     return -1;
    }
    while(Recorrer->Siguiente!=NULL) {
      Borrar = Recorrer;
      Recorrer= Recorrer->Siguiente;
    }
   if(Borrar==NULL) {
       Borrar = *Inicio;
      *Inicio = NULL;
      delete (Borrar);
   } else {
     delete (Borrar->Siguiente);
     Borrar->Siguiente=NULL;
   }
    return 0;
}
int main(){
	Nodo *inicio = NULL;
    int opcion=0;
    int opcion2=0;
    string elemento;

    do {
        cout<<"\n0 Salir del programa";
		    cout<<"\n1 Insertar elemento en la lista";
        cout<<"\n2 Borrar elemento de la lista";
        cout<<"\n3 Listar elementos de la lista";
        cout<<"\n ...? ";
        cin>>opcion;
        switch(opcion) {

          case 1:
          	cout<<"Inserte elemento: ";
          	cin>>elemento;
            InsertarElemento(&inicio, elemento);
            break;
          case 2:
           	cout<<"\n0 Volver";
            cout<<"\n1 Borrar elemento de el  final";
            cout<<"\n2 Borrar elemento de el principio";
            cout<<"\n3 Borrar elemento de la mitad";
        
            cin>>opcion2;

               switch(opcion2) {

                 case 1:
                 	BorrarElementoFinal(&inicio);
                    break;
                 case 2:
                    BorrarElementoPrincipio(&inicio);
                    break;
                 case 3:
                    BorrarElementoMedio(&inicio);
                    break;
               }
               break;
          case 3:
           	ListarElementos(inicio);
            break;
        }
    } while(opcion!=0);
  system("PAUSE");
  return 0;
}