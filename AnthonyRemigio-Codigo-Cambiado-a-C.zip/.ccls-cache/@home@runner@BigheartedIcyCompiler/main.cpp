#include <iostream>
using namespace std;
class Nodo
{
	public:
		string Nombre;
		Nodo * Siguiente;
};
int InsertarElemento(Nodo **Inicio, string dato)
{
	Nodo* nuevo_nodo = new Nodo();
	Nodo *ultimo = *Inicio;
	nuevo_nodo->Nombre = dato;
	nuevo_nodo->Siguiente = NULL;
		if (*Inicio == NULL)
	{
		*Inicio = nuevo_nodo;
		return 0;
	}
		while (ultimo->Siguiente != NULL)
	{
		ultimo = ultimo->Siguiente;
	}
		ultimo->Siguiente = nuevo_nodo;
		return 0;
	};	
void ListarElementos(Nodo *Inicio)
{
    
     Nodo *Recorrer = Inicio;
     
     cout<<"\nListado de elementos de la lista";
     cout<<"\n===================================\n";
     
     while(Recorrer!=NULL)
     {
        cout<<Recorrer->Nombre<<endl;
        Recorrer=Recorrer->Siguiente;
     }
     cout<<"\n===================================\n";
}
int BorrarElementoListaPrincipio(Nodo **Inicio)
{
	Nodo *Borrar=NULL;
    if ( *Inicio ==NULL) {
       cout<<"\nNo hay elementos que borrar\n";
       return -1;
    } else {
      Borrar = *Inicio;
      *Inicio = (*Inicio)->Siguiente;
      delete (Borrar);
    }
    return 0;
}
int BorrarElementoListaFinal(Nodo **Inicio)
{
    Nodo *Borrar=NULL;
    Nodo *Recorrer=NULL;
    Recorrer=*Inicio;
    if(Recorrer==NULL) {
     cout<<"\nNo existen elementos que borrar\n";
     return -1;
    }
    while(Recorrer->Siguiente!=NULL) {
      Borrar = Recorrer;
      Recorrer= Recorrer->Siguiente;
    }
   if(Borrar==NULL) {
       Borrar = *Inicio;
      *Inicio = NULL;
      delete (Borrar);
   } else {
     delete (Borrar->Siguiente);
     Borrar->Siguiente=NULL;
   }
    return 0;
}
int BorrarElementoIntermedio(Nodo **Inicio)
{ 
    Nodo *Recorrer=NULL;
    Nodo *Borrar=NULL;
    Nodo *Anterior=NULL;
    
    string NombreBuscar;
    int encontrado=0;
    
    cout<<"\nNombre a eliminar: ";
    cin>>NombreBuscar;
   
    if (*Inicio==NULL) {
       cout<<"\nNo hay elementos que borrar\n";
       return -1;
    } else {
        
        cout<<"\nBuscando: ",NombreBuscar;
        Recorrer = *Inicio;
        Anterior = *Inicio;
        while(Recorrer!=NULL && encontrado==0)
        {
            
            cout<<".";
            if(Recorrer->Nombre.compare(NombreBuscar)==0) {
                cout<<" (Encontrado Ok)\n";
                encontrado=1;
                Borrar = Recorrer;
                if(Recorrer==*Inicio) {
                    *Inicio = Recorrer->Siguiente;
                } else {
                    Anterior->Siguiente = Borrar->Siguiente;
                }
                delete (Borrar);
            } else {
                
                Anterior = Recorrer;
                Recorrer=Recorrer->Siguiente;
            }
        }
        
    }
    return 0;
}
int main(){
	Nodo *inicio = NULL;
    int opcion=0;
    int opcion2=0;
    string elemento;

    do {
        cout<<"\n1.- Insertar elemento en la lista.";
        cout<<"\n2.- Listar elementos de la lista.";
        cout<<"\n3.- Borrar elemento de la lista.";
        cout<<"\n0.- Salir del programa.";
        cout<<"\n=====================================";
        cout<<"\nOpcion ...: ";
        cin>>opcion;
        switch(opcion) {

          case 1:
          	cout<<"\nInserte elemento a agregar: ";
          	cin>>elemento;
            InsertarElemento(&inicio, elemento);
            break;
          case 2:
            ListarElementos(inicio);
            break;
          case 3:
            cout<<"\n(0) Volver Menu Anterior.";
            cout<<"\n(1) Borrar al final.";
            cout<<"\n(2) Borrar al principio.";
            cout<<"\n(3) Borrar Intermedio.";
            cout<<"\n.... ";
            cin>>opcion2;

               switch(opcion2) {

                 case 1:
                 	BorrarElementoListaFinal(&inicio);
                    break;
                 case 2:
                    BorrarElementoListaPrincipio(&inicio);
                    break;
                 case 3:
                    BorrarElementoIntermedio(&inicio);
                    break;
               }
               break;
        }
    } while(opcion!=0);
  system("PAUSE");
  return 0;
}