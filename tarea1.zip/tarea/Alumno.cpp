#include "Alumno.h"

void Alumno::setAttributes(std::string nombre, float n1, float n2, float n3, float n4){
    this->nombre = nombre;
    this->n1 = n1;
    this->n2 = n2;
    this->n3 = n3;
    this->n4 = n4;
}

void Alumno::imprimeme(){
    std::cout << "Mi nombre es: " << this->nombre << std::endl;
    std::cout << "Mi n1: "        << this->n1     << std::endl;
    std::cout << "Mi n2: "        << this->n2     << std::endl;
    std::cout << "Mi n3: "        << this->n3     << std::endl;
    std::cout << "Mi n4: "        << this->n4     << std::endl;
}