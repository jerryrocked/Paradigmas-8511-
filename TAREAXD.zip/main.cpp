#include <iostream>
#include <string.h>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;


int main() {
    string archivo1="archivo1.txt";
    ifstream archivo(archivo1.c_str());
    string linea,nomb,n1,n2,n3,n4;
    int res,lon,i,x=0,j=0;
	  float num1[50],num2[50],num3[50],num4[50];
    string alumnos[400];
    char b,l;

    while (getline(archivo,linea)) {
        cout<<linea<<endl;
        lon = linea.length();
        for (i=0;i<lon;i++){
            l=linea[i];
            b=' ';
            if (l!=b){
                if (j==0)
                    nomb=nomb+linea[i];
                if (j==1)
                    n1=n1+linea[i];
                if (j==2)
                    n2=n2+linea[i];
                if (j==3)
                    n3=n3+linea[i];
                if (j==4)
                    n4=n4+linea[i];    
            }
            else
                j++;
        }

        float n1_float = std::stof(n1);
        float n2_float = std::stof(n2);
        float n3_float = std::stof(n3);
        float n4_float = std::stof(n4);

      // ARRREGLO
        alumnos[x] = nomb;
      	num1[x]= n1_float;
      	num2[x]= n2_float;
      	num3[x]= n3_float;
      	num4[x]= n4_float;
      	x++;

        j=0;
        nomb=" ";
        n1=" ";
        n2=" ";
        n3=" ";
        n4=" ";
		}
    cout<<"\n ----------------Datos----------------"<<endl;
		for(int f = 0 ; f<x; f++){  
			cout<<alumnos[f]<<"\n";
			cout<<num1[f]<<"\n";
			cout<<num2[f]<<"\n";
			cout<<num3[f]<<"\n";
			cout<<num4[f]<<"\n";
		}
}