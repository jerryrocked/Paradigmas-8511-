#include <iostream>
#include <string.h>
#include <fstream>
using namespace std;

int main() {
  string archivo1="archivo1.txt";
  ifstream archivo(archivo1.c_str());
  string linea,nomb,n1,n2,n3,n4;
  int cont=0,res,lon,i,j=0;
  string nombres[100];
  int notas[4][4],notas1[4];
  char b,l;
  while (getline(archivo,linea))
  {
    lon = linea.length();
    for (i=0;i<lon;i++)
    {
      l=linea[i];
      b=' ';
      if (l!=b){
        if (j==0)
          nomb=nomb+linea[i];
        if (j==1)
          n1=n1+linea[i];
        if (j==2)
          n2=n2+linea[i];
        if (j==3)
          n3=n3+linea[i];
        if (j==4)
          n4=n4+linea[i];    
        }
        else
          j++;
    }
    nombres[cont] = nomb;
    int num1 = stoi(n1);
    int num2 = stoi(n2);
    int num3 = stoi(n3);
    int num4 = stoi(n4);

    for(i=0;i<4;i++){
      if(i==0){
        notas1[i]=num1;
      }
      if(i==1){
        notas1[i]=num2;
      }
      if(i==2){
        notas1[i]=num3;
      }
      if(i==3){
        notas1[i]=num4;
      }
    }
    for(i=0;i<4;i++){
        notas[cont][i]=notas1[i];
      }
    cout<<nombres[cont]<<endl;
    cout<<notas[cont][0]<<endl;
    cout<<notas[cont][1]<<endl;
    cout<<notas[cont][2]<<endl;
    cout<<notas[cont][3]<<endl;
    j=0;
    nomb="\0";
    n1="\0";
    n2="\0";
    n3="\0";
    n4="\0";
    cont=cont+1;
    }
  
  }
