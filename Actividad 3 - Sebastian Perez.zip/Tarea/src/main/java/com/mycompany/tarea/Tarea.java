package com.mycompany.tarea;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author snper
 */
public class Tarea {
    
    static void CuentaAhorro(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese el dinero a calcular, solo valores numericos.");
        double dinero = reader.nextInt();
        double tasa = 1;
        double tasa_dinero = dinero*tasa;
        double tasa_dinero_ganado = tasa_dinero/100;
        double dinero_final = dinero+tasa_dinero_ganado;
        System.out.println("El dinero que ganaria en un año es: "+tasa_dinero_ganado);
        System.out.println("El dinero total con el que terminaria al año es: "+dinero_final);
        
    }
    static void CuentaCorriente(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese el dinero a calcular, solo valores numericos.");
        double dinero = reader.nextInt();
        double tasa = 0.5;
        double tasa_dinero = dinero*tasa;
        double tasa_dinero_ganado = tasa_dinero/100;
        double dinero_final = dinero+tasa_dinero_ganado;
        System.out.println("El dinero que ganaria en un año es: "+tasa_dinero_ganado);
        System.out.println("El dinero total con el que terminaria al año es: "+dinero_final);
    }
    static void CuentaPlazoFijo3Meses(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese el dinero a calcular, solo valores numericos.");
        double dinero = reader.nextInt();
        double tasa = 1.2;
        double tasa_dinero = dinero*tasa;
        double tasa_dinero_ganado_mensual = tasa_dinero/100;
        double tasa_dinero_ganado = tasa_dinero_ganado_mensual*3;
        double dinero_final = dinero+tasa_dinero_ganado;
        System.out.println("El dinero que ganaria en un año es: "+tasa_dinero_ganado);
        System.out.println("El dinero total con el que terminaria al año es: "+dinero_final);
    }
    static void CuentaPlazoFijo6Meses(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese el dinero a calcular, solo valores numericos.");
        double dinero = reader.nextInt();
        double tasa = 1.2;
        double tasa_dinero = dinero*tasa;
        double tasa_dinero_ganado_mensual = tasa_dinero/100;
        double tasa_dinero_ganado = tasa_dinero_ganado_mensual*6;
        double dinero_final = dinero+tasa_dinero_ganado;
        System.out.println("El dinero que ganaria en un año es: "+tasa_dinero_ganado);
        System.out.println("El dinero total con el que terminaria al año es: "+dinero_final);
    }
    public static void main(String[] args) {
        Scanner op = new Scanner(System.in);
        boolean salir = false;
        int opcion, opcionplazo;
        while(!salir){
            System.out.println("Banco XYZ.");
            System.out.println("Menu para simular cuentas de futuros clientes.");
            System.out.println("--------------------");
            System.out.println("1. Cuenta Ahorro.");
            System.out.println("2. Cuenta Corriente.");
            System.out.println("3. Cuenta a Plazo Fijo.");
            System.out.println("4. Salir.");
            
            try {
                System.out.println("Escribe una de las opciones");
                opcion = op.nextInt();
                switch (opcion) {
                    case 1 -> {
                        System.out.println("Iniciando modulo de vista previa de una Cuenta Ahorro.");
                        CuentaAhorro();
                    }
                    case 2 -> {
                        System.out.println("Iniciando modulo de vista previa de una Cuenta Corriente.");
                        CuentaCorriente();
                    }
                    case 3 -> {
                        System.out.println("Iniciando modulo de vista previa de una Cuenta a Plazo Fijo.");
                        System.out.println("Eliga el plazo:");
                        System.out.println("1. 3 meses.");
                        System.out.println("2. 6 meses.");
                        opcionplazo = op.nextInt();
                        if (opcionplazo == 1){
                            CuentaPlazoFijo3Meses();
                        }
                        else if (opcionplazo == 2){
                            CuentaPlazoFijo6Meses();
                        }
                        else{
                            System.out.println("Porfavor ingrese una opcion valida.");
                        }
                    }
                    case 4 -> salir = true;
                    default -> System.out.println("Solo números entre 1 y 4");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                op.next();
            }
        }
    }
}
